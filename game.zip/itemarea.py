from tkinter import *

root = Tk()


canvas = Canvas(width = 750, height = 600, bg = 'yellow')
# pack the canvas into a frame/form
canvas.pack(expand = YES, fill = BOTH)
# load the .gif image file
# put in your own gif file here, may need to add full path
gif1 = PhotoImage(file = 'top self background.gif')
# put gif image on canvas

# pic's upper left corner (NW) on the canvas is at x=50 y=10
canvas.create_image(0, 0, image = gif1, anchor = NW)


#bubblesort for the items

"""this will allow the price of the items to ascend or descend
    by the users action"""

def lowToHigh(myList):
    for i in range(0, len (myList)-1):
        for j in range(0, len (myList)-1-i):
            if myList[j] > myList[j+1]:
                myList[j], myList[j+1] = myList[j+1] , myList[j]
    return myList

def highToLow(myList):
    for i in range(0, len (myList)-1):
        for j in range(0, len (myList)-1-i):
            if myList[j+1] > myList[j]:
                myList[j+1], myList[j] = myList[j] , myList[j+1]
    return myList

List = [485,5,7,9,8,6,4,2,5,1,3,5,78]

#Low price function

def pricedrop():
    print (lowToHigh(List))

button1=Button(root,bg='yellow', text='Descending', command=pricedrop)
button1.pack(side=RIGHT)

#High price function
def priceRaise():
    print (highToLow(List))

button2=Button(root,bg='yellow', text='Ascending', command=priceRaise)
button2.pack(side=RIGHT)

def quit():
    sys.exit()
button3=Button(root,bg='yellow', text ='Exit Game', command=exit)
button3.pack(side=LEFT)
#This makes user to go back to start menu

def iteamarea():
    """this screen is destroyed after user presses button and next screen
         appears."""
    def kill2():
        root.destroy()
        from listpage import itemarea
        iteamarea()

    button2 = Button(root, bg = 'yellow', text = 'Go to List', command = kill2)
    button2.pack()


if __name__ == '__main__':
    iteamarea()


root.mainloop()
