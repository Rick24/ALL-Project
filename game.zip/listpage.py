from tkinter import *

root=Tk()

canvas = Canvas(width = 330, height = 470, bg = 'yellow')
# pack the canvas into a frame/form
canvas.pack()
# load the .gif image file
# put in your own gif file here, may need to add full path
gif1 = PhotoImage(file = 'listpage.gif')
# put gif image on canvas

# pic's upper left corner (NW) on the canvas is at x=50 y=10
canvas.create_image(0,0, image = gif1, anchor = NW)

button2 = Button(root, bg = 'yellow', text = 'go home')
button2.pack(side=RIGHT)

#This makes user to go back to start men
def itemarea():
    """this screen is destroyed after user presses button and next screen
         appears."""
    def kill1():
        root.destroy()
        from sudogame import listpage
        itemarea()

    button1 = Button(root, bg = 'green', text = 'Go Back', command = kill1)
    button1.pack()

if __name__ == '__main__':
    itemarea()


root.mainloop()
